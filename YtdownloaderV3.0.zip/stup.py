import tkinter as tk
from tkinter import ttk
from tkinter import filedialog
import ttkbootstrap as ttk
import shutil
import os
sciezka = ''
try:
    with open('stylee.txt', 'r') as f:
        style = f.read()
except:
    style = 'litera'
try:
    with open('bardzowazne.txt', 'r') as f:
        nnn = f.read()
        has = True
except:
    has = False


def choose():
    global sciezka
    sciezka = filedialog.askdirectory()
    sciezka2 = 'wybrana sciezka:\n' + sciezka
    lbox1.configure(text = sciezka2)
    button_frame.pack_forget()
    lbox1.pack()
    apply_box.pack(padx = 10, side = 'left')
    button_frame.pack()
def apply():
    try:
        with open('bardzowazne.txt', 'r') as f:
            nnn = f.read()
    except:
        pass
    global sciezka
    sciezka = sciezka + '\\ytvids'
    os.mkdir(sciezka)
    if has == True:
        names = os.listdir(nnn)
        for name in names:
            shutil.move(os.path.join(nnn, name), sciezka)
        os.rmdir(nnn)

    with open('bardzowazne.txt', 'w') as f:
        f.seek(0)
        f.truncate()
        f.write(sciezka)
    if has == False:
        output_box['text'] = 'ustalono sciezke'
        outt = ttk.Label(window, text = 'nie usuwaj pliku "bardzowanze.txt"',font = "Calibri 30 bold", bootstyle = 'danger')
    output_box.pack()
    try:
        outt.pack()
    except:
        pass
sss = ''
btext = ''
if has == True:
    fontt = "Calibri 20 bold"
    hass = 'hm wygląda  na to ze masz juz folder wideo\n     czy chciałbys zmienic jego ściezke?'
    sss = 'warning'
    sciezka = nnn
    sciezka2 = 'aktualna sciezka:\n' + sciezka
    btext = 'zmien sciezke'
else:
    hass = 'wybierz sciezke instalacji'
    sss = 'default'
    fontt = "Calibri 20 bold"
    btext = 'ustal sciezke'
    sciezka2 = sciezka
window = ttk.Window(themename=style)
window.title('setup')
window.geometry('600x500')


title_label = tk.Label(window, text="Setup", font="Calibri 35 bold")
title_label.pack()

label1 = ttk.Label(window, text=hass, font=fontt, bootstyle = sss)
label1.pack(pady = 10)

if has == True:
    lbox = tk.Label(window, text=sciezka2, font="Calibri 20 bold")
    lbox.pack(pady = 5)

lbox1 = tk.Label(window, text=sciezka2, font="Calibri 20 bold")

button_frame = tk.Frame()
button_frame.pack()

choose_box = ttk.Button(button_frame, text=btext, command=choose, bootstyle = 'info')
choose_box.pack(side = 'left')


apply_box = tk.Button(button_frame, text='zatwierdz', command=apply)

output_box = ttk.Label(window, text='zmieniono sciezke', font="Calibri 30", bootstyle='success')



window.mainloop()
exit()
