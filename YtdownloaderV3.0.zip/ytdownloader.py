import tkinter as tk
from tkinter import ttk
import ttkbootstrap as ttk
from pytube import YouTube
import os
import sys

killl = False
pppp = os.getcwd()

os.chdir(pppp)
tekst = 'wpisz link:'
miss = False
try:
    with open('stylee.txt', 'r') as f:
        stylee = f.read()
except:
    stylee = 'litera'
try:
    with open('bardzowazne.txt', 'r') as f:
        nnn = f.read()
    os.chdir(nnn)
except:
    miss = True
statt = 'default'
def close():
    global stylee
    window.style.theme_use(stylee)
    extra_window.destroy()
def change():
    global stylee
    global window
    stylee1 = combovar.get()
    window.style.theme_use(stylee1)
def zastosuj():
    os.chdir(pppp)
    global stylee
    
    stylee = combovar.get()
    with open('stylee.txt', 'w') as frr:
        frr.seek(0)
        frr.truncate()
        frr.write(stylee)
    window.style.theme_use(stylee)
    labell = ttk.Label(extra_window, text = 'zastosowano zmiany', font = 'Calibri 10 bold', bootstyle = 'success')
    labell.pack()
    os.chdir(nnn)

def style():
    global combovar
    global extra_window

    extra_window = ttk.Toplevel()
    extra_window.protocol('WM_DELETE_WINDOW', close)
    extra_window.title('style picker')
    extra_window.geometry('200x300')
    ttk.Label(extra_window, text = 'Wybierz styl', font = 'Calibri 20 bold').pack(side='top',pady=10)
    styles = ['solar', 'superhero', 'darkly', 'cyborg', 'vapor']
    combovar = tk.StringVar()
    combo = ttk.Combobox(extra_window, value=styles, textvariable=combovar)
    combo.pack()
    button2 = ttk.Button(extra_window, text = 'zastosuj', command=zastosuj)
    resetbutton = ttk.Button(extra_window, text='zresetuj styl', command=reset)
    combo.bind('<<ComboboxSelected>>', lambda event: change() )
    button2.pack(pady=10)
    resetbutton.pack()


def infooo():
    title = vid.title
    author = vid.author
    channel = vid.channel_url
    files = vid.streams.get_highest_resolution().filesize
    files = files / 1024
    files = files / 1024
    files = int(float(files))
    files = str(files) + 'MB'
    views = vid.views
    texttt = 'tytuł : ', title, '\nautor: ', author, '\nkanał: ', channel, '\nrozmiar: ', files, '\nwyswietlenia: ', views


    extra_window2 = ttk.Toplevel()
    extra_window2.title('video info')
    extra_window2.geometry('400x700')
    infolabel = ttk.Label(extra_window2, text=texttt, font='calibri 20 bold')
    kanal = ttk.Button(extra_window2, text='odiwedz kanal', command = lambda: os.startfile(channel))
    infolabel.pack()
    kanal.pack()
jakosc1 = 0
def jakosc():
    global jakosc1
    global video
    global jakosci

    jakosc1 += 1
    if jakosc1 % 2 != 0:
        video = vid.streams.get_lowest_resolution()
        jakosci['text'] = 'najnizsza jakosc'
    elif jakosc1 % 2 == 0:
        video = vid.streams.get_highest_resolution()
        jakosci['text'] = 'najwyzsza jakosc'
pobieranie = 0
iloscpobran = 0
def pobierz():
    found = False
    global statt
    global varrr
    global vid
    global jakosci
    global iloscpobran
    global pobieranie
    global framee
    global statuslabel
    global folderbutton
    iloscpobran += 1
    if iloscpobran > 1:
        try:
            framee.pack_forget()
        except:
            pass
        try:
            statuslabel.pack_forget()
            folderbutton.pack_forget()
        except:
            pass

    pobieranie = 1
    try:
        varrr = tk.IntVar()
        link = entry.get()
        vid = YouTube(link, on_progress_callback=info)

        video = vid.streams.get_highest_resolution()
        vidtitle = vid.title + '.mp4'
        vidtitle1 = vidtitle
        for filename in os.listdir(nnn):
            try:
                vidtitle1 = vidtitle1.replace('|', '')
            except:
                pass
            try:
                vidtitle1 = vidtitle1.replace('<', '')
            except:
                pass
            try:
                vidtitle1 = vidtitle1.replace('>', '')
            except:
                pass
            try:
                vidtitle1 = vidtitle1.replace('/', '')
            except:
                pass
            try:
                vidtitle1 = vidtitle1.replace('\\', '')
            except:
                pass
            try:
                vidtitle1 = vidtitle1.replace(':', '')
            except:
                pass
            try:
                vidtitle1 = vidtitle1.replace('*', '')
            except:
                pass
            try:
                vidtitle1 = vidtitle1.replace('"', '')
            except:
                pass
            try:
                vidtitle1 = vidtitle1.replace('?', '')
            except:
                pass
            print(vidtitle1)
            if vidtitle1 == filename:
                statuslabel.pack()
                statuslabel.configure(text='video istnieje', bootstyle='warning')
                folderbutton = ttk.Button(window, text='otwórz folder', command=lambda: os.startfile(nnn))
                folderbutton.pack()
                found = True
        if found == False:
            title_label1.configure(text = 'pobierasz:\n' + vid.title)
            framee = ttk.Frame(window)
            infoo = ttk.Button(framee, text='zatwierdz pobranie', command=lambda: varrr.set(1))
            vidinfo = ttk.Button(framee, text='info', command=infooo)

            infoo.pack(side = 'left', padx=10)
            vidinfo.pack(side = 'left')

            framee.pack()

            infoo.wait_variable(varrr)
            if killl == False:
                infoo.pack_forget()

                framee.pack_forget()
                frame.pack_forget()
                ppp.pack()
                progressbar.pack()

                video.download()


                statuslabel.configure(text='pobrano', bootstyle='success')
                statuslabel.pack()
                folderbutton = ttk.Button(window, text='otwórz folder', command= lambda: os.startfile(nnn))
                folderbutton.pack(pady= 10)



    except Exception as problem:
        print(problem)
        eee = str(problem)
        ee = list(eee)
        if ee[14] == 'c':
            tekstt = '                  błąd pobierania\n sprawdz czy dobrze wspisałes link'
        elif ee[12] == 'i':
            tekstt = '                  błąd pobierania\nfilm objęty ograniczeniem wiekowym'
        else:
            tekstt = 'nieznany bład pobierania'

        statuslabel.pack()
        statuslabel.configure(text = tekstt, bootstyle = 'danger')

def info(stream, chunk, bytes):
    size = stream.filesize
    downloaded = size - bytes
    percentage = downloaded / size * 100
    per = str(int(percentage))
    progressbar['value'] = per
    ppp.configure(text = per + '%')
    ppp.update()
    progressbar.update()
def reset():
    global stylee
    stylee = 'litera'
    window.style.theme_use('litera')
    os.chdir(pppp)
    with open('stylee.txt', 'w') as frr:
        frr.seek(0)
        frr.truncate()
        frr.write(stylee)
    os.chdir(nnn)




def closee():
    global varrr
    global killl
    killl = True
    if pobieranie == 1:
        varrr.set(1)
    else:
        pass

    os.chdir(pppp)
    os.startfile('closee.bat')



window = ttk.Window(themename=stylee)
window.title('downloader')
window.geometry('600x400')
window.protocol('WM_DELETE_WINDOW', closee)
if miss == True:
    title_label = ttk.Label(window, text='Brak Folderu', font='Calibri 40 bold', bootstyle='danger')
    title_label.pack()
    window.mainloop()
    exit()

title_label = ttk.Label(window, text = 'YouTube Downloader', font='Calibri 40 bold')
title_label.pack()

title_label1 = ttk.Label(window, text = tekst, font='Calibri 20 bold')
title_label1.pack(pady = 10)

frame = ttk.Frame(window)
frame.pack(pady = 10)

entry = ttk.Entry(frame)
entry.pack(side = 'left')

button = ttk.Button(frame, text = 'pobierz', command=pobierz)
button.pack(side = 'left', padx = 10)



ppp = ttk.Label(window, text='',font = 'Calibri 10 bold')

progressbar = ttk.Progressbar(window, orient='horizontal',mode='determinate', length=280)

styleframe = ttk.Frame(window)
styleframe.pack(side='bottom', ipady=10,ipadx=200)

stylebutton = ttk.Button(styleframe, text = 'zmien styl', command=style)
stylebutton.pack(side='right')







statuslabel = ttk.Label(window, text = '', font='Calibri 20 bold', bootstyle = 'succes')



window.mainloop()

